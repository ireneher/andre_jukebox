1. Imports OBJs from input directory.
2. Creates Arnold Surface Shaders and connects texture maps found at given directory.
3. Publishes (with archive versioning) the asset and the reference files.

To run: {MAYA_PY} /path/to/mtoa_convert/main.py
